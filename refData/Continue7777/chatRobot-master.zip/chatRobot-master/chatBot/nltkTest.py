import nltk
from nltk.corpus import brown
nltk.download()